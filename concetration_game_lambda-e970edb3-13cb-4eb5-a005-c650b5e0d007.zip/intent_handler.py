import launch_handler
import session_end_handler
import game_logic

def handle(request, session):
    intent = request['intent']
    intent_name = request['intent']['name']

    if intent_name == "AMAZON.HelpIntent":
        return game_logic.help_function(request, session)
    elif intent_name == "AMAZON.CancelIntent" or intent_name == "AMAZON.StopIntent":
        return session_end_handler.handle(request, session)
    else:
        return game_logic.handle(request, session)
        
