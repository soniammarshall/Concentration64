from alexa import build_response, build_speechlet_response
import random

def handle(request, session):
    card_title = "Good bye"
    bye = random.choice(["bon voyage", "au revoir", "g'day" ])
    speech_output = '<say-as interpret-as="interjection">{}</say-as>! Thank you for playing concentration sixty four.'.format(bye)
    should_end_session = True
    
    speech = build_speechlet_response(
        card_title, speech_output, '', should_end_session)
        
    #speech = build_simple_response('Tata.', True)
    return build_response({}, speech)

    
