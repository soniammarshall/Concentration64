from images import get_image_url

def build_speechlet_response(title, output, reprompt_text, should_end_session):
    
    
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak> " + output + "</speak>"
        },
        'card': {
            'type': 'Simple',
            'title': title,
            'content': output
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }

def build_speechlet_response_with_image(title, output, reprompt_text, should_end_session):
    
    
    return {
        'outputSpeech': {
            'type': 'SSML',
            'ssml': "<speak> " + output + "</speak>"
        },
        "card": {
          "type": "Standard",
          "title": title,
          "text": output,
          "image": {
            "largeImageUrl": get_image_url(title)
          }
        },
        'reprompt': {
            'outputSpeech': {
                'type': 'PlainText',
                'text': reprompt_text
            }
        },
        'shouldEndSession': should_end_session
    }


def build_speechlet(speech, should_end_session=False, card=None, reprompt=None):
    card = card if card else build_simple_card('', '')
    reprompt = reprompt if reprompt else ''
    
    return {
        'outputSpeech': speech,
        'card': card,
        'reprompt': {'outputSpeech': build_simple_speech(reprompt)},
        'shouldEndSession': should_end_session
    }
    
    # return {
    #     'outputSpeech': {
    #         'type': 'SSML',
    #         'ssml': "<speak> " + output + "</speak>"
    #     },
    #     'card': {
    #         'type': 'Simple',
    #         'title': title,
    #         'content': output
    #     },
    #     'reprompt': {
    #         'outputSpeech': {
    #             'type': 'PlainText',
    #             'text': reprompt_text
    #         }
    #     },
    #     'shouldEndSession': should_end_session
    # }

def build_ssml_speech(ssml):
    return {
            'type': 'SSML',
            'ssml': ssml
        }

def build_simple_speech(text):
    return {
            'type': 'PlainText',
            'text': text
        }
    
def build_simple_card(title, content):
    return {
            'type': 'Simple',
            'title': title,
            'content': content
    }


def build_response(session_attributes, speechlet_response):
    return {
        'version': '1.0',
        'sessionAttributes': session_attributes,
        'response': speechlet_response
    }
