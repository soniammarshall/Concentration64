from urllib.request import urlopen
import json

def get_image_url(item):
    url_template = 'https://pixabay.com/api/?key=8732674-f2b4f592641d5063033ebbdc8&q={}&image_type=photo'
    r = urlopen(url_template.format(item))
    return json.load(r).get('hits', [{}])[0].get('largeImageURL', None)