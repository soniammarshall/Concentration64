from __future__ import print_function
import words
from alexa import build_response, build_speechlet_response, build_speechlet_response_with_image
import random


def handle(request, session):
    intent = request['intent']
    intent_name = request['intent']['name']

    if intent_name == "playAgainIntent":
        return play_again(intent, session)
    elif intent_name == "chooseCategoryIntent":
        return choose_category(intent, session)
    elif intent_name in ["vegIntent", "fruitIntent", "buildingsIntent", "bodyPartsIntent", "clothesIntent", "animalsIntent", "unknownIntent"]: 
        return check_word(intent, session)
    elif intent_name == "categoryInfoIntent":
        return category_info_request(intent, session)
    else:
        raise ValueError("Invalid intent")




# --------------- Functions that control the skill's behavior ------------------
def play_again(intent, session):
    
    speech_output = "Great! Pick a category."
    reprompt_text = "I thought you wanted to play again? Choose a category!"
    
    session_attributes = {'current score': 0}
    should_end_session = False 
    
    card_title = ""
    
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))  

def check_word(intent, session):
    print(session)
    remaining_words = session.get('attributes', {}).get('remaining words', [])
    category = session.get('attributes', {}).get('category', '')
    slots = intent['slots']
    curr_score = session.get('attributes', {}).get('current score', 0)
    end_type = ""
    
    session_attributes = {}
    
    speech_output = ""
    reprompt_text = ""
    should_end_session = False
    
    if category == '':
        speech_output = "That's not a category! " + get_categories()
        should_end_session = False
    elif category in slots:
        # ie word user said is in correct category
        # get word from slot
        if 'resolutions' in slots[category]:
            if 'values' in slots[category]['resolutions']['resolutionsPerAuthority'][0]:
                word = slots[category]['resolutions']['resolutionsPerAuthority'][0]['values'][0]['value']['name']
                print(word)
            else:
                word = ""
        elif 'value' in slots[category]:
            word = slots[category]['value']
        # check i fword has been used before or not
        
        if word in remaining_words:
            if word == 'cat' or word == 'kitten':
                meow = random.choice(['https://s3.amazonaws.com/ask-soundlibrary/animals/amzn_sfx_cat_purr_meow_01.mp3', 'https://s3.amazonaws.com/ask-soundlibrary/animals/amzn_sfx_cat_long_meow_1x_01.mp3', 'https://s3.amazonaws.com/ask-soundlibrary/animals/amzn_sfx_cat_angry_meow_1x_01.mp3'])
                speech_output = '<audio src=\'{}\'/>'.format(meow)
            elif word == 'elephant':
                speech_output = "<audio src='https://s3.amazonaws.com/ask-soundlibrary/animals/amzn_sfx_elephant_03.mp3'/>"
            elif word == 'horse':
                speech_output = "<audio src='https://s3.amazonaws.com/ask-soundlibrary/animals/amzn_sfx_horse_whinny_01.mp3'/>"
                
            remaining_words.remove(word)
            curr_score += 1
            
            if remaining_words:
                alexas_word = alexas_turn(intent, session, remaining_words)
                remaining_words.remove(alexas_word)
                speech_output = speech_output + "My turn! {} ".format(alexas_word)
            else:
                wow = random.choice(["wow", "woo hoo", "well done", "sigh", "oops", "oh snap", "oh boy", "mamma mia"])
                speech_output += ' <say-as interpret-as="interjection">{}</say-as>! I\'ve run out of words. You win.'.format(wow)
                speech_output += end_game_message(curr_score)
                
            session_attributes = {'remaining words': remaining_words, 'category': category, 'current score': curr_score}
            end_type = "hesitation"
            reprompt_text = "You hesitated, game over! " + end_game_message(curr_score)
            should_end_session = False
            
        else:
            boo = random.choice(["boo", "boo hoo", "checkmate", "eek", "gotcha", "oh snap", "oops", "whoops a daisy", "there there" ])
            speech_output +='<say-as interpret-as="interjection">{0}</say-as>! {1} has been said before. Game over!'.format(boo, word, curr_score)
            speech_output += end_game_message(curr_score)
            should_end_session = False
    
    else:
        speech_output = "That's not in the category {}, game over!".format(category)
        speech_output += end_game_message(end_type, curr_score)
        should_end_session = False
  
    card_title = ""
    
    
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))   
        
def choose_category(intent, session):
    slots = intent['slots']
    category = None
    if 'category' in slots:
        if 'resolutions' in slots['category']:
            category = slots['category']['resolutions']['resolutionsPerAuthority'][0]['values'][0]['value']['name']
        elif 'value' in slots['category']:
            category = slots['category']['value']
            
    session_attributes = {}
    if category is None:
        speech_output = "I didn't hear you, repeat your category please."
    elif category in words.categories:
        remaining_words = words.categories[category]
        session_attributes = {'remaining words': remaining_words, 'category': category}
        
        speech_output = "The category is {}, let's begin! You start.".format(category)
    else:
        speech_output = "{} is not a valid category. Choose a new one!".format(category)
    
    should_end_session = False 
    
    card_title = ""
    reprompt_text = ""
    
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))  
        
def alexas_turn(intent, session, remaining_words):
    word = random.choice(remaining_words)
    return word
    
def get_categories():
    result = "The categories you can choose from are: " + ', '.join(words.categories.keys()) 
    return result

def end_game_message(curr_score):
    
    message = " Your score is {}. Your current highscore is seventeen.".format(curr_score)
    message += " You can say play again to start over, or say cancel to quit the game."
    return message
    
def help_function(request, session):
    
    speech_output = "To play concentration sixty-four choose a category and say a word from it. I will then say another one and we keep going as long as possible. Be careful not to say a word that has already been said. "
    speech_output += get_categories()
    speech_output += ". Pick a category to begin!"
    
    should_end_session = False 
    
    session_attributes = {}
    card_title = ""
    reprompt_text = ""
    
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))  

def category_info_request(intent, session):
    
    speech_output = get_categories() + ". Pick a category to begin."

    session_attributes = {}
    should_end_session = False 
    
    card_title = ""
    reprompt_text = ""
    
    return build_response(session_attributes, build_speechlet_response(
        card_title, speech_output, reprompt_text, should_end_session))  
    
    





