import launch_handler
import session_end_handler 
import intent_handler

def handle_event(event, context):
    session = event['session']
    request = event['request']
        
    if request['type'] == "LaunchRequest":
        return launch_handler.handle(request, session)
    elif request['type'] == "SessionEndedRequest":
        return session_end_handler.handle(request, session)
    elif request['type'] == "IntentRequest":
        return intent_handler.handle(request, session)

