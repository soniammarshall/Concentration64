from alexa import *
import random

def handle(request, session):
    session_attributes = {'current score': 0}
    greetings = ["aloha", "ahoy", "ahoy matey", "ahoy me hearties", "howdy", "bonjour"]
    hello = random.choice(greetings)
    
    speech_template = '{}! Welcome Amazonians to concentration sixty four! Please pick a category'
    ssml = '<speak>{}</speak>'.format(speech_template.format('<say-as interpret-as="interjection">{}</say-as>'.format(hello)))
    card_text = speech_template.format(hello)
    card_title = "Welcome"
    reprompt_text = "Choose a category."
    
    return build_response(
        session_attributes, 
        build_speechlet(
            speech=build_ssml_speech(ssml), 
            should_end_session=False,
            card=build_simple_card(card_title, card_text),
            reprompt=reprompt_text
        ))