
import alexa_event_handler

def lambda_handler(event, context):
    return alexa_event_handler.handle_event(event, context)
 